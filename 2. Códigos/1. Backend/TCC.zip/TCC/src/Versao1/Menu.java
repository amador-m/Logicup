package Versao1;

import java.util.ArrayList;

public class Menu {
    private ArrayList<Usuario> usuarios = new ArrayList<>();

    public Menu() {
        String menuOp = """
                    MENU DE OPÇÕES
                1. Criar conta
                2. Login
                3. Apagar conta
                4. Configurações
                5. Explicações teóricas
                6. Quizz rápido
                7. Desafios de código
                9. Ranking e progresso
                10. Sair
                
                Escolha a opção desejada:
                """;
    }
}
