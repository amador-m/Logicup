package Versao1;

import javax.swing.*;

public class Quizzes {
    int nrQuizz = 0;
    String enunciado;

    public void setNrQuizz() {
        this.nrQuizz++;
    }

    public void Quizz1() {
        setNrQuizz();
        String op;
        String enunciado1 = "Quais são as etapas/caixotes de todo código?";
        this.enunciado = enunciado1;
        String[] alternativas = {"Entrada, saída e processamento de dados", "\nDeclaração de variáveis e cálculo", "\nNenhuma das alternativas"};

        do {
            op = (String) JOptionPane.showInputDialog(null,enunciado1+"\nEscolha uma das opções abaixo:","Pergunta 1",JOptionPane.QUESTION_MESSAGE,null,alternativas,alternativas[0]);
            if (op.equals(alternativas[0])) {
                JOptionPane.showMessageDialog(null, "Você respondeu corretamente", "Resultado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Tente novamente", "Resultado", JOptionPane.INFORMATION_MESSAGE);
            }
        } while (!op.equals(alternativas[0]));
    }
}
