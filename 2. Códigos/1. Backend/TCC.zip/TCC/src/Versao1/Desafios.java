package Versao1;

import javax.swing.JOptionPane;

public class Desafios {
    int nrDesafio = 0;
    String enunciado;

    public void setNrDesafio() {
        this.nrDesafio++;
    }

    public void Desafio1() {
        setNrDesafio();
        String enunciado1 = "Crie um programa em Java que leia 2 números inteiros e os some.\n" + "Digite sua resposta em código:";
        this.enunciado = enunciado1;
        String respostaUsuario,resolucao;

        do {
            respostaUsuario = JOptionPane.showInputDialog(null, enunciado1, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);

            resolucao = "\nScanner sc = new Scanner(System.in);\n" +
                        "int a = sc.nextInt();\n" +
                        "int b = sc.nextInt();\n" +
                        "System.out.println(\"Soma: \" + (a + b));\n";

            if(respostaUsuario == resolucao) {
                JOptionPane.showMessageDialog(null, "Parabéns, você acertou!!", "Correção", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Tente novamente, você consegue na próxima!!", "Correção", JOptionPane.INFORMATION_MESSAGE);
            }
        } while(!respostaUsuario.equals(resolucao)); // novo not equals

        // 1. uma pessoa pode dar um nome diferente para o scanner dela do que eu estabeleci
        // 2. ele vai considerar até os \n na hora da correção... not cool :(
        // 3. e se eu colocar o scanner no enunciado e a pessoa começa a partir dele??

        JOptionPane.showMessageDialog(null, resolucao, "Resolução da Questão " + nrDesafio, JOptionPane.INFORMATION_MESSAGE);
    }


    public void Desafio2() {
        setNrDesafio();
        enunciado = "Crie um programa que leia dois números e exiba o maior.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio3() {
        setNrDesafio();
        enunciado = "Crie um programa que leia um número e diga se ele é par ou ímpar.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio4() {
        setNrDesafio();
        enunciado = "Crie um programa que leia a idade de uma pessoa e diga se ela é maior de idade.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio5() {
        setNrDesafio();
        enunciado = "Crie um programa que leia um número e exiba sua tabuada de 1 a 10.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio6() {
        setNrDesafio();
        enunciado = "Crie um programa que leia 5 números e exiba a média.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio7() {
        setNrDesafio();
        enunciado = "Crie um programa que leia uma palavra e diga quantas vogais ela possui.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio8() {
        setNrDesafio();
        enunciado = "Crie uma classe chamada Pessoa com atributos nome e idade. Instancie um objeto e exiba seus dados.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Desafio9() {
        setNrDesafio();
        enunciado = "Crie um programa que leia uma lista de nomes e exiba-os em ordem alfabética.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public void Questao10() {
        setNrDesafio();
        enunciado = "Crie um programa que leia uma matriz 3x3 e exiba a soma dos elementos da diagonal principal.";
        JOptionPane.showInputDialog(null, enunciado, "Questão " + nrDesafio, JOptionPane.QUESTION_MESSAGE);
    }

    public static void main(String[] args) { // teste
        Desafios q = new Desafios();
        Quizzes q1 = new Quizzes();
        q1.Quizz1();
        q.Desafio1();
        q.Desafio2();
        q.Desafio3();
        q.Desafio4();
        q.Desafio5();
        q.Desafio6();
        q.Desafio7();
        q.Desafio8();
        q.Desafio9();
        q.Questao10();
    }
}
